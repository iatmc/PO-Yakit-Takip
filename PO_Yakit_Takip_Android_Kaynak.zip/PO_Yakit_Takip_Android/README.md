# PO Yakıt Takip – Sunucusuz Android projesi

Bu proje, Petrol Ofisi'nin resmi Kocaeli fiyat sayfasındaki GEBZE satırını doğrudan Android cihazdan okur. Harici sunucu, Firebase veya abonelik gerektirmez.

## Davranış
- Uygulama açıldığında hemen fiyat yenilemesi dener.
- WorkManager, internet bağlantısı olduğunda periyodik arka plan kontrolü planlar (Android'in minimum periyodik aralığı 15 dakikadır; sistem bu işi geciktirebilir).
- İnternet yokken yeni veri alınmaz; son başarılı fiyatlar cihazda saklanır.
- Benzin, motorin ve LPG fiyat değişiklikleri bildirim üretir.
- Motorin baz değeri 01.11.2026 / 100,80 TL/L olarak başlar. ±%7 eşiğinde bildirim verir. Baz otomatik sıfırlanmaz.
- Kullanıcı "Bazı mevcut fiyata sıfırla" ile baz değeri manuel günceller.

## Derleme
1. Android Studio (JDK 17) kurun.
2. Bu klasörü Android Studio ile açın.
3. Gradle senkronizasyonunu tamamlayın.
4. Telefonda USB hata ayıklamayı açıp Run kullanın veya Build > Build APK(s) seçin.

APK çıktısı `app/build/outputs/apk/debug/app-debug.apk` altında oluşur.

## Veri kaynağı ve önemli not
Resmi kaynak: https://www.petrolofisi.com.tr/akaryakit-fiyatlari/kocaeli-akaryakit-fiyatlari
Sayfa düzeni değişirse uygulama güvenli biçimde hata verir; tahmini fiyat kaydetmez. Kaynaktaki tablo ilk sütun fiyatlarını KDV dahil litre fiyatı olarak okur. Resmi site yapısı zaman içinde değişebileceği için ilk gerçek cihaz testinde Gebze satırındaki üç fiyatın doğrulanması gerekir.

## Sınırlamalar
Android cihaz tamamen kapalıyken uygulama çalışmaz. İnternet geri geldiğinde WorkManager kontrolü sistem zamanlamasına bağlıdır; uygulamayı açmak anında kontrolü başlatır. Android 13+ bildirim izni gerekir.
