package com.po.yakittakip

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        scheduleFuelWork(this)
        val repo = FuelRepository(this)
        setContent {
            var prices by remember { mutableStateOf(repo.saved()) }
            var loading by remember { mutableStateOf(false) }
            var status by remember { mutableStateOf("Uygulama açıldı. Fiyat kontrolü başlatılıyor.") }
            val pct = prices?.let { ((it.diesel - repo.baseDiesel()) / repo.baseDiesel()) * 100.0 }
            LaunchedEffect(Unit) {
                loading = true
                try { prices = repo.refresh(); status = "Son kontrol başarılı" }
                catch (e: Exception) { status = e.message ?: "Güncelleme başarısız" }
                loading = false
            }
            MaterialTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(Modifier.padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("PO YAKIT TAKİP", style = MaterialTheme.typography.headlineMedium)
                        Text("Kocaeli / Gebze • Petrol Ofisi resmi kaynağı", style = MaterialTheme.typography.bodyMedium)
                        Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("GÜNCEL LİTRE FİYATLARI", style = MaterialTheme.typography.titleMedium)
                            PriceLine("Benzin", prices?.petrol)
                            PriceLine("Motorin", prices?.diesel)
                            PriceLine("LPG", prices?.lpg)
                            Text(prices?.let { "Son güncelleme: ${SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")).format(Date(it.fetchedAt))}" } ?: "Henüz fiyat kaydı yok")
                        } }
                        Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("MOTORİN ENDEKSİ", style = MaterialTheme.typography.titleMedium)
                            Text("Baz fiyat: ${"%.2f".format(Locale("tr", "TR"), repo.baseDiesel())} TL/L")
                            Text("Baz tarihi: ${repo.baseDate()}")
                            Text("Güncel değişim: ${pct?.let { "%+.2f%%".format(Locale.US, it) } ?: "—"}", style = MaterialTheme.typography.headlineSmall)
                            Text("Uyarı sınırları: +%7 / -%7. Baz otomatik değişmez.")
                            Button(onClick = { repo.setBaseToCurrent(); status = "Baz fiyat mevcut motorin fiyatına sıfırlandı." }, enabled = prices != null) { Text("Bazı mevcut fiyata sıfırla") }
                        } }
                        Button(onClick = {
                            lifecycleScope.launch {
                                loading = true
                                try { prices = repo.refresh(); status = "Son kontrol başarılı" }
                                catch (e: Exception) { status = e.message ?: "Güncelleme başarısız" }
                                loading = false
                            }
                        }, modifier = Modifier.fillMaxWidth(), enabled = !loading) { Text(if (loading) "Kontrol ediliyor…" else "Şimdi güncelle") }
                        Text(status, style = MaterialTheme.typography.bodySmall)
                        Text("Otomatik kontrol internet bağlantısı varken yapılır. Android pil tasarrufu nedeniyle arka plan kontrolü gecikebilir. Uygulama açıldığında hemen yenileme denenir.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable private fun PriceLine(label: String, value: Double?) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value?.let { "%.2f TL/L".format(Locale("tr", "TR"), it) } ?: "—", style = MaterialTheme.typography.titleMedium)
    }
}
