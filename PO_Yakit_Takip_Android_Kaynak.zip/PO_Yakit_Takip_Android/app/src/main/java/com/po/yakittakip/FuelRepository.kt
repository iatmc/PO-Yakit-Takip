package com.po.yakittakip

import android.content.Context
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private const val PREFS = "po_fuel_prefs"
private const val URL = "https://www.petrolofisi.com.tr/akaryakit-fiyatlari/kocaeli-akaryakit-fiyatlari"

data class FuelPrices(val petrol: Double, val diesel: Double, val lpg: Double, val fetchedAt: Long)

class FuelRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()

    fun saved(): FuelPrices? {
        if (!prefs.contains("diesel")) return null
        return FuelPrices(prefs.getString("petrol", "0")!!.toDouble(), prefs.getString("diesel", "0")!!.toDouble(), prefs.getString("lpg", "0")!!.toDouble(), prefs.getLong("fetched", 0L))
    }

    fun baseDiesel(): Double = prefs.getString("base_diesel", "100.80")!!.toDouble()
    fun baseDate(): String = prefs.getString("base_date", "01.11.2026") ?: "01.11.2026"
    fun setBaseToCurrent() {
        val p = saved() ?: return
        prefs.edit().putString("base_diesel", p.diesel.toString()).putString("base_date", SimpleDateFormat("dd.MM.yyyy", Locale("tr", "TR")).format(Date())).apply()
    }

    suspend fun refresh(): FuelPrices = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(URL).header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Petrol Ofisi sayfasına erişilemedi (HTTP ${response.code})")
            val html = response.body?.string() ?: error("Kaynak boş yanıt verdi")
            val doc = Jsoup.parse(html)
            val row = doc.select("tr").firstOrNull { it.text().contains("GEBZE", ignoreCase = true) }
                ?: error("Resmi sayfada GEBZE satırı bulunamadı; fiyat tahmini yapılmadı")
            val cells = row.select("th,td")
            if (cells.size < 7) error("Fiyat tablosunun biçimi değişmiş; veri kaydedilmedi")
            fun firstPrice(index: Int): Double {
                val raw = cells[index].text().replace(',', '.')
                val match = Regex("(?<!\\d)(\\d{2,3}\\.\\d{2})(?!\\d)").find(raw)
                    ?: error("Fiyat alanı okunamadı")
                return match.groupValues[1].toDouble()
            }
            // Resmi tablodaki ilk tutar KDV dahil litre fiyatıdır.
            val next = FuelPrices(firstPrice(1), firstPrice(2), firstPrice(6), System.currentTimeMillis())
            val old = saved()
            prefs.edit().putString("petrol", next.petrol.toString()).putString("diesel", next.diesel.toString()).putString("lpg", next.lpg.toString()).putLong("fetched", next.fetchedAt).apply()
            if (old != null) {
                val changes = mutableListOf<String>()
                if (old.petrol != next.petrol) changes += "Benzin ${old.petrol} → ${next.petrol} TL/L"
                if (old.diesel != next.diesel) changes += "Motorin ${old.diesel} → ${next.diesel} TL/L"
                if (old.lpg != next.lpg) changes += "LPG ${old.lpg} → ${next.lpg} TL/L"
                if (changes.isNotEmpty()) FuelNotifier.show(context, "Petrol Ofisi fiyat değişikliği", changes.joinToString("\n"))
            }
            val pct = ((next.diesel - baseDiesel()) / baseDiesel()) * 100.0
            val alreadyAlerted = prefs.getString("threshold_alert", "") ?: ""
            val direction = when { pct >= 7.0 -> "UP"; pct <= -7.0 -> "DOWN"; else -> "" }
            if (direction.isNotEmpty() && direction != alreadyAlerted) {
                FuelNotifier.show(context, "Motorin %7 eşiği aşıldı", "Baz: ${baseDiesel()} TL/L (${baseDate()})\nGüncel: ${next.diesel} TL/L\nDeğişim: ${"%.2f".format(Locale.US, pct)}%")
                prefs.edit().putString("threshold_alert", direction).apply()
            }
            if (direction.isEmpty() && alreadyAlerted.isNotEmpty()) prefs.edit().putString("threshold_alert", "").apply()
            next
        }
    }
}

class FuelWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        FuelRepository(applicationContext).refresh()
        Result.success()
    } catch (_: Exception) { Result.retry() }
}

fun scheduleFuelWork(context: Context) {
    val request = PeriodicWorkRequestBuilder<FuelWorker>(15, TimeUnit.MINUTES)
        .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
        .build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork("po_fuel_refresh", ExistingPeriodicWorkPolicy.KEEP, request)
}
